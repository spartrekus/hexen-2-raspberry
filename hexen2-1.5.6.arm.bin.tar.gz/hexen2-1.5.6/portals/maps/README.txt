These are fixed entities for several maps.  uHexen2 version 1.5.0-RC1 or
newer can load them automatically.  To see what was fixed in a map, see
the text file accompanying the ent file.  If you aren't happy with the
fixed entities for a map, just delete the ent file and the map's original
embedded entities will be used.
